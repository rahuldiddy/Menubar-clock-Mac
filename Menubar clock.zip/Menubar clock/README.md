# Menu Bar Clock

A native macOS menu bar application (SwiftUI, macOS 15+) that shows an additional
clock — Dallas (`America/Chicago`) by default — directly in the menu bar:

```
􀐫 Dallas 6:10 AM
```

It can also show several clocks at once:

```
􀐫 Dallas 6:10 AM  |  London 12:10 PM
```

## Features

- **Menu bar only** — no Dock icon (`LSUIElement`).
- Built entirely with SwiftUI's `MenuBarExtra`.
- SF Symbols `clock` icon before the time.
- Updates every second from a single shared timer (minimal CPU/memory).
- Uses the system menu-bar appearance, so it blends in with Apple's own clock and
  follows light/dark mode automatically.
- Clicking the item opens a menu with:
  - today's date,
  - current local time,
  - each configured clock (Dallas, …),
  - **Settings…** (⌘,),
  - **Quit** (⌘Q).
- **Date / calendar** with selectable formats (`Jun 13`, `June 13`, `6/13/2026`,
  `2026-06-13`) and an optional weekday prefix (no comma, e.g. `Fri Jun 13`):
  - always shown in the menu header,
  - optionally shown in the menu bar,
  - world clocks on a different calendar day show their date too
    (e.g. `Tokyo   8:10 PM  · Jun 14`).
- **Settings window**:
  - add / remove time zones,
  - rename each clock's label,
  - toggle which clocks appear in the menu bar,
  - toggle seconds on/off,
  - toggle 12-hour / 24-hour format,
  - choose the date format, toggle the day of week, and toggle the menu-bar date.
- All settings persist in `UserDefaults`.
- Daylight saving is handled automatically (`TimeZone` + `DateFormatter` resolve the
  correct offset per date).

## Project structure

```
MenuBarClock.xcodeproj/         # Xcode 16+ project (synchronized file groups)
MenuBarClock/
├── MenuBarClockApp.swift        # @main App + MenuBarExtra + Settings scenes
├── Models/
│   ├── ClockItem.swift          # One configurable clock (Codable)
│   └── DateStyle.swift          # Selectable date formats (Codable)
├── Stores/
│   ├── SettingsStore.swift      # UserDefaults-backed, observable settings
│   └── ClockTicker.swift        # Single 1-second tick for all time views
├── Utilities/
│   └── TimeFormatting.swift     # Cached DateFormatter helpers
├── Views/
│   ├── MenuBarLabel.swift       # Live content shown IN the menu bar
│   ├── MenuContentView.swift    # The dropdown menu
│   └── SettingsView.swift       # General + Clocks settings tabs
└── Assets.xcassets/             # App icon (all sizes) + accent color
Tools/
└── GenerateAppIcon.swift        # Regenerates icon PNGs: swift Tools/GenerateAppIcon.swift
```

> The Xcode project uses **synchronized file-system groups** (Xcode 16+), so any
> `.swift` file you add anywhere under `MenuBarClock/` is compiled automatically — no
> need to edit the project file.

## Build & run in Xcode

1. Open **`MenuBarClock.xcodeproj`** in Xcode 16 or later (macOS 15 SDK).
2. Select the **MenuBarClock** scheme and **My Mac** as the run destination.
3. Press **⌘R**.

The app has no window and no Dock icon — look for the clock in the **menu bar** at the
top-right of the screen. Click it to open the menu; choose **Settings…** to configure
time zones and formatting. Use **Quit** (⌘Q) from the menu to stop it.

### Build from the command line (optional)

```bash
xcodebuild -project MenuBarClock.xcodeproj -scheme MenuBarClock -configuration Debug build
open ~/Library/Developer/Xcode/DerivedData/MenuBarClock-*/Build/Products/Debug/MenuBarClock.app
```

## Notes

- Default configuration seeds one clock: **Dallas / America/Chicago**, shown in the
  menu bar. Change it (or add more) from **Settings → Clocks**.
- To run on a stock signing setup, Xcode uses the automatic *"Sign to Run Locally"*
  identity — no Apple Developer account is required for local builds.
