import Foundation

/// A single configurable clock: a user-facing label plus the time zone it tracks.
///
/// `Codable` so the whole list round-trips through `UserDefaults` as JSON.
struct ClockItem: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()

    /// Display name shown in the menu and (optionally) the menu bar, e.g. "Dallas".
    var label: String

    /// IANA time zone identifier, e.g. "America/Chicago".
    var timeZoneIdentifier: String

    /// Whether this clock is rendered directly in the menu bar.
    var showInMenuBar: Bool = false

    /// Resolved `TimeZone`. Falls back to the current zone if the identifier is invalid.
    /// `TimeZone` + `DateFormatter` compute the correct offset per-date, so daylight
    /// saving transitions are handled automatically.
    var timeZone: TimeZone {
        TimeZone(identifier: timeZoneIdentifier) ?? .current
    }
}
