import Foundation

/// Selectable date display formats (the date "body", without the weekday).
///
/// Whether the weekday is shown is controlled separately by `SettingsStore.showWeekday`.
/// The raw value is the `DateFormatter` pattern, which makes the enum trivially
/// `Codable` for persistence in `UserDefaults`.
enum DateStyle: String, CaseIterable, Identifiable, Codable {
    case dayMonthShort = "MMM d"        // Jun 13
    case dayMonthLong  = "MMMM d"       // June 13
    case numeric       = "M/d/yyyy"     // 6/13/2026
    case iso           = "yyyy-MM-dd"   // 2026-06-13

    var id: String { rawValue }

    /// Human-readable example shown in the settings picker.
    var displayName: String {
        switch self {
        case .dayMonthShort: return "Jun 13"
        case .dayMonthLong:  return "June 13"
        case .numeric:       return "6/13/2026"
        case .iso:           return "2026-06-13"
        }
    }

    /// Weekday pattern paired with this style: full ("Friday") for the long month
    /// style, abbreviated ("Fri") otherwise.
    private var weekdayPattern: String {
        self == .dayMonthLong ? "EEEE" : "EEE"
    }

    /// The full `DateFormatter` pattern, optionally prefixed with the weekday.
    /// No comma is inserted between the weekday and the date (e.g. "Fri Jun 13").
    func pattern(showWeekday: Bool) -> String {
        showWeekday ? "\(weekdayPattern) \(rawValue)" : rawValue
    }

    /// A compact pattern used for the "different day" hint next to world clocks.
    static let compactPattern = "MMM d"
}
