import SwiftUI

/// Root settings window, split into a "General" tab (formatting options) and a
/// "Clocks" tab (add/remove/rename time zones).
struct SettingsView: View {
    var body: some View {
        TabView {
            GeneralSettingsView()
                .tabItem { Label("General", systemImage: "gearshape") }

            ClocksSettingsView()
                .tabItem { Label("Clocks", systemImage: "clock") }
        }
        .frame(width: 520)
        .onAppear {
            // Ensure the window is focused when opened from an accessory app.
            NSApplication.shared.activate(ignoringOtherApps: true)
        }
    }
}

/// Time-format preferences.
struct GeneralSettingsView: View {
    @EnvironmentObject private var settings: SettingsStore

    var body: some View {
        Form {
            Section("Time") {
                Toggle("Show seconds", isOn: $settings.showSeconds)
                Toggle("Use 24-hour time", isOn: $settings.use24Hour)
            }

            Section("Date") {
                Picker("Date format", selection: $settings.dateStyle) {
                    ForEach(DateStyle.allCases) { style in
                        Text(style.displayName).tag(style)
                    }
                }
                Toggle("Show day of week", isOn: $settings.showWeekday)
                Toggle("Show date in menu bar", isOn: $settings.showDateInMenuBar)
            }
        }
        .formStyle(.grouped)
        .frame(height: 300)
    }
}

/// Manage the list of clocks: add, remove, rename, choose time zone, and pick which
/// ones appear directly in the menu bar.
struct ClocksSettingsView: View {
    @EnvironmentObject private var settings: SettingsStore

    var body: some View {
        VStack(spacing: 0) {
            List {
                ForEach($settings.clocks) { $clock in
                    ClockRow(clock: $clock)
                }
                .onDelete(perform: settings.removeClocks)
            }

            Divider()

            HStack {
                Button(action: settings.addClock) {
                    Label("Add Time Zone", systemImage: "plus")
                }
                Spacer()
                Text("\(settings.clocks.count) clock\(settings.clocks.count == 1 ? "" : "s")")
                    .foregroundStyle(.secondary)
                    .font(.callout)
            }
            .padding(8)
        }
        .frame(height: 360)
    }
}

/// A single editable row in the clocks list.
private struct ClockRow: View {
    @Binding var clock: ClockItem

    private let timeZoneIdentifiers = TimeZone.knownTimeZoneIdentifiers.sorted()

    var body: some View {
        HStack(spacing: 10) {
            TextField("Label", text: $clock.label)
                .textFieldStyle(.roundedBorder)
                .frame(width: 130)

            Picker("Time Zone", selection: $clock.timeZoneIdentifier) {
                ForEach(timeZoneIdentifiers, id: \.self) { identifier in
                    Text(identifier.replacingOccurrences(of: "_", with: " "))
                        .tag(identifier)
                }
            }
            .labelsHidden()

            Spacer(minLength: 4)

            Toggle("Menu Bar", isOn: $clock.showInMenuBar)
                .toggleStyle(.checkbox)
                .help("Show this clock directly in the menu bar")
        }
        .padding(.vertical, 2)
    }
}
