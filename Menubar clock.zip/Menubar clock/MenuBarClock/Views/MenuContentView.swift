import SwiftUI

/// The dropdown menu shown when the menu bar item is clicked.
///
/// Contents (top to bottom):
///   • Today's date header
///   • Current local time
///   • Each configured clock (Dallas, …)
///   • Settings…
///   • Quit
struct MenuContentView: View {
    @EnvironmentObject private var settings: SettingsStore
    @EnvironmentObject private var ticker: ClockTicker

    @Environment(\.openSettings) private var openSettings

    var body: some View {
        Text(TimeFormatting.date(ticker.now,
                                 timeZone: .current,
                                 style: settings.dateStyle,
                                 showWeekday: settings.showWeekday))

        Divider()

        // Current local time.
        Text("Local   \(localTime)")

        // Every configured clock (the default config includes Dallas).
        ForEach(settings.clocks) { clock in
            Text(menuRow(for: clock))
        }

        Divider()

        Button("Settings…") {
            openSettings()
            // Bring the (accessory) app forward so the window is focused.
            NSApplication.shared.activate(ignoringOtherApps: true)
        }
        .keyboardShortcut(",", modifiers: .command)

        Divider()

        Button("Quit Menu Bar Clock") {
            NSApplication.shared.terminate(nil)
        }
        .keyboardShortcut("q", modifiers: .command)
    }

    private var localTime: String {
        TimeFormatting.time(ticker.now,
                            timeZone: .current,
                            use24Hour: settings.use24Hour,
                            showSeconds: settings.showSeconds)
    }

    private func time(for clock: ClockItem) -> String {
        TimeFormatting.time(ticker.now,
                            timeZone: clock.timeZone,
                            use24Hour: settings.use24Hour,
                            showSeconds: settings.showSeconds)
    }

    /// "Dallas   6:10 AM" — with a date hint appended when the clock is on a
    /// different calendar day than the local one, e.g. "Tokyo   8:10 PM  · Jun 14".
    private func menuRow(for clock: ClockItem) -> String {
        var row = "\(clock.label)   \(time(for: clock))"
        if TimeFormatting.isDifferentDay(ticker.now, timeZone: clock.timeZone) {
            let day = TimeFormatting.string(ticker.now,
                                            timeZone: clock.timeZone,
                                            pattern: DateStyle.compactPattern)
            row += "  · \(day)"
        }
        return row
    }
}
