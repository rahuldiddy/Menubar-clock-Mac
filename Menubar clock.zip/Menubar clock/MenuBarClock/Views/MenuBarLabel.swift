import SwiftUI

/// The live content shown directly in the macOS menu bar.
///
/// Renders one or more clocks as plain text, e.g.
/// `Dallas 6:10 AM` or, with several menu-bar clocks enabled,
/// `Dallas 6:10 AM  |  London 12:10 PM`.
///
/// No custom font is applied: `MenuBarExtra` renders `Text` with the system menu-bar
/// appearance, so the item matches Apple's own clock and adapts to light/dark mode
/// automatically.
struct MenuBarLabel: View {
    @EnvironmentObject private var settings: SettingsStore
    @EnvironmentObject private var ticker: ClockTicker

    var body: some View {
        Text(menuBarText)
    }

    private var menuBarText: String {
        var parts: [String] = []

        // Optional leading date, in the local time zone.
        if settings.showDateInMenuBar {
            parts.append(TimeFormatting.date(ticker.now,
                                             timeZone: .current,
                                             style: settings.dateStyle,
                                             showWeekday: settings.showWeekday))
        }

        let clocks = settings.menuBarClocks
        if !clocks.isEmpty {
            let times = clocks
                .map { clock in
                    let time = TimeFormatting.time(ticker.now,
                                                   timeZone: clock.timeZone,
                                                   use24Hour: settings.use24Hour,
                                                   showSeconds: settings.showSeconds)
                    return "\(clock.label) \(time)"
                }
                .joined(separator: "  |  ")
            parts.append(times)
        }

        return parts.isEmpty ? "Clock" : parts.joined(separator: "   ")
    }
}
