import Foundation

/// Centralised, cached date/time formatting.
///
/// `DateFormatter` is relatively expensive to create, so instances are cached by
/// (time zone + pattern). With a once-per-second tick and a handful of clocks this
/// keeps formatting essentially free. All access happens on the main thread (SwiftUI
/// view bodies), so no extra synchronisation is required.
enum TimeFormatting {
    private static var cache: [String: DateFormatter] = [:]

    /// Builds the `DateFormatter` pattern for the current display options.
    static func timePattern(use24Hour: Bool, showSeconds: Bool) -> String {
        switch (use24Hour, showSeconds) {
        case (false, false): return "h:mm a"      // 6:10 AM
        case (false, true):  return "h:mm:ss a"   // 6:10:42 AM
        case (true, false):  return "HH:mm"       // 18:10
        case (true, true):   return "HH:mm:ss"    // 18:10:42
        }
    }

    /// Formats `date` for the given time zone using an explicit pattern.
    static func string(_ date: Date, timeZone: TimeZone, pattern: String) -> String {
        let key = timeZone.identifier + "|" + pattern
        let formatter: DateFormatter
        if let cached = cache[key] {
            formatter = cached
        } else {
            let new = DateFormatter()
            new.locale = .current
            new.timeZone = timeZone
            new.dateFormat = pattern
            cache[key] = new
            formatter = new
        }
        return formatter.string(from: date)
    }

    /// Convenience: formats the time portion using the supplied display options.
    static func time(_ date: Date,
                     timeZone: TimeZone,
                     use24Hour: Bool,
                     showSeconds: Bool) -> String {
        string(date,
               timeZone: timeZone,
               pattern: timePattern(use24Hour: use24Hour, showSeconds: showSeconds))
    }

    /// Formats the date portion using a chosen `DateStyle`, optionally prefixed
    /// with the weekday.
    static func date(_ date: Date,
                     timeZone: TimeZone,
                     style: DateStyle,
                     showWeekday: Bool) -> String {
        string(date, timeZone: timeZone, pattern: style.pattern(showWeekday: showWeekday))
    }

    /// `true` when `date` falls on a different calendar day in `timeZone` than it does
    /// in the local time zone. Used to flag world clocks that are on another day.
    static func isDifferentDay(_ date: Date, timeZone: TimeZone) -> Bool {
        var local = Calendar.current
        local.timeZone = .current
        var other = Calendar.current
        other.timeZone = timeZone
        let fields: Set<Calendar.Component> = [.year, .month, .day]
        return local.dateComponents(fields, from: date) != other.dateComponents(fields, from: date)
    }
}
