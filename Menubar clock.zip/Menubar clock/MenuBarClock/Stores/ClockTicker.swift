import SwiftUI

/// Publishes the current `Date` once per second so every time view can refresh.
///
/// A single timer drives the whole app, which keeps CPU and memory use minimal.
/// The timer runs on the main run loop in `.common` mode so it keeps firing even
/// while a menu is open, and a small `tolerance` lets the system coalesce wake-ups.
final class ClockTicker: ObservableObject {
    @Published private(set) var now: Date = Date()

    private var timer: Timer?

    init() {
        start()
    }

    private func start() {
        let timer = Timer(timeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.now = Date()
        }
        // Allow ~100 ms of slack; the OS can batch this with other wake-ups.
        timer.tolerance = 0.1
        RunLoop.main.add(timer, forMode: .common)
        self.timer = timer
    }

    deinit {
        timer?.invalidate()
    }
}
