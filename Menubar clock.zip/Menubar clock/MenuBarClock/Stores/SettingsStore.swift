import SwiftUI

/// Observable, `UserDefaults`-backed store for all user configuration.
///
/// Every mutation is written back to `UserDefaults` via `didSet`, so settings persist
/// across launches with no explicit "save" step.
final class SettingsStore: ObservableObject {
    /// All configured clocks. The first launch seeds a single Dallas clock.
    @Published var clocks: [ClockItem] {
        didSet { persistClocks() }
    }

    /// Show seconds in every rendered time (menu bar + menu).
    @Published var showSeconds: Bool {
        didSet { UserDefaults.standard.set(showSeconds, forKey: Keys.showSeconds) }
    }

    /// Use 24-hour time instead of 12-hour with AM/PM.
    @Published var use24Hour: Bool {
        didSet { UserDefaults.standard.set(use24Hour, forKey: Keys.use24Hour) }
    }

    /// The date format used for the menu header and the optional menu-bar date.
    @Published var dateStyle: DateStyle {
        didSet { UserDefaults.standard.set(dateStyle.rawValue, forKey: Keys.dateStyle) }
    }

    /// Whether the weekday (e.g. "Fri") is prefixed to the date.
    @Published var showWeekday: Bool {
        didSet { UserDefaults.standard.set(showWeekday, forKey: Keys.showWeekday) }
    }

    /// Show the (local) date directly in the menu bar, before the clocks.
    @Published var showDateInMenuBar: Bool {
        didSet { UserDefaults.standard.set(showDateInMenuBar, forKey: Keys.showDateInMenuBar) }
    }

    private enum Keys {
        static let clocks = "clocks"
        static let showSeconds = "showSeconds"
        static let use24Hour = "use24Hour"
        static let dateStyle = "dateStyle"
        static let showWeekday = "showWeekday"
        static let showDateInMenuBar = "showDateInMenuBar"
    }

    init() {
        let defaults = UserDefaults.standard

        if let data = defaults.data(forKey: Keys.clocks),
           let decoded = try? JSONDecoder().decode([ClockItem].self, from: data),
           !decoded.isEmpty {
            clocks = decoded
        } else {
            // Default configuration: Dallas (America/Chicago) shown in the menu bar.
            clocks = [
                ClockItem(label: "Dallas",
                          timeZoneIdentifier: "America/Chicago",
                          showInMenuBar: true)
            ]
        }

        // `object(forKey:)` lets us distinguish "never set" from an explicit `false`.
        showSeconds = defaults.object(forKey: Keys.showSeconds) as? Bool ?? false
        use24Hour = defaults.object(forKey: Keys.use24Hour) as? Bool ?? false

        if let raw = defaults.string(forKey: Keys.dateStyle),
           let style = DateStyle(rawValue: raw) {
            dateStyle = style
        } else {
            dateStyle = .dayMonthShort
        }
        showWeekday = defaults.object(forKey: Keys.showWeekday) as? Bool ?? true
        showDateInMenuBar = defaults.object(forKey: Keys.showDateInMenuBar) as? Bool ?? false
    }

    // MARK: - Derived state

    /// Clocks that should appear directly in the menu bar, in configured order.
    var menuBarClocks: [ClockItem] {
        clocks.filter(\.showInMenuBar)
    }

    // MARK: - Mutations

    func addClock() {
        clocks.append(
            ClockItem(label: "New Clock",
                      timeZoneIdentifier: TimeZone.current.identifier,
                      showInMenuBar: false)
        )
    }

    func removeClocks(at offsets: IndexSet) {
        clocks.remove(atOffsets: offsets)
    }

    // MARK: - Persistence

    private func persistClocks() {
        guard let data = try? JSONEncoder().encode(clocks) else { return }
        UserDefaults.standard.set(data, forKey: Keys.clocks)
    }
}
