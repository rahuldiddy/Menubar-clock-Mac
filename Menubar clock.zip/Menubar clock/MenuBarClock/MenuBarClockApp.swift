import SwiftUI

/// Entry point for the menu bar clock.
///
/// The app runs as a menu bar accessory (no Dock icon — see `INFOPLIST_KEY_LSUIElement`
/// in the build settings). It exposes a single `MenuBarExtra` whose label is the live
/// clock shown in the system menu bar, plus a standard `Settings` scene.
@main
struct MenuBarClockApp: App {
    /// Persisted user configuration (time zones, formatting options).
    @StateObject private var settings = SettingsStore()

    /// A single shared 1-second tick that drives every live time view.
    @StateObject private var ticker = ClockTicker()

    var body: some Scene {
        MenuBarExtra {
            MenuContentView()
                .environmentObject(settings)
                .environmentObject(ticker)
        } label: {
            MenuBarLabel()
                .environmentObject(settings)
                .environmentObject(ticker)
        }
        // `.menu` gives us the native dropdown menu (vs. a popover window).
        .menuBarExtraStyle(.menu)

        // Standard Settings scene, reachable from the menu's "Settings…" item.
        Settings {
            SettingsView()
                .environmentObject(settings)
        }
    }
}
