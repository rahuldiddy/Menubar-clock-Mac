import AppKit
import CoreGraphics

let outDir = "/Users/rahul_diddy/Menubar clock/MenuBarClock/Assets.xcassets/AppIcon.appiconset"
let cs = CGColorSpaceCreateDeviceRGB()

func c(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, _ a: CGFloat = 1) -> CGColor {
    CGColor(srgbRed: r, green: g, blue: b, alpha: a)
}

/// Point on a clock face for `deg` measured clockwise from 12 o'clock (y-down context).
func pt(_ cx: CGFloat, _ cy: CGFloat, _ r: CGFloat, _ deg: CGFloat) -> CGPoint {
    let a = deg * .pi / 180
    return CGPoint(x: cx + r * sin(a), y: cy - r * cos(a))
}

func drawIcon(pixel: Int) -> Data {
    let size = CGFloat(pixel)
    guard let ctx = CGContext(data: nil, width: pixel, height: pixel,
                              bitsPerComponent: 8, bytesPerRow: 0, space: cs,
                              bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
        fatalError("ctx")
    }

    // Flip to a y-down coordinate system: 12 o'clock is up, angles go clockwise.
    ctx.translateBy(x: 0, y: size)
    ctx.scaleBy(x: 1, y: -1)

    // Stroke the given path filled with a linear gradient.
    func strokeGradient(_ path: CGPath, lineWidth: CGFloat, colors: [CGColor],
                        start: CGPoint, end: CGPoint) {
        ctx.saveGState()
        ctx.setLineWidth(lineWidth)
        ctx.setLineCap(.round)
        ctx.setLineJoin(.round)
        ctx.addPath(path)
        ctx.replacePathWithStrokedPath()
        ctx.clip()
        let g = CGGradient(colorsSpace: cs, colors: colors as CFArray, locations: nil)!
        ctx.drawLinearGradient(g, start: start, end: end, options: [])
        ctx.restoreGState()
    }

    // MARK: Rounded-rect tile with a dark vertical gradient.
    let inset = size * 0.055
    let rect = CGRect(x: inset, y: inset, width: size - 2 * inset, height: size - 2 * inset)
    let tile = rect.width
    let corner = tile * 0.2237
    let tilePath = CGPath(roundedRect: rect, cornerWidth: corner, cornerHeight: corner, transform: nil)

    ctx.saveGState()
    ctx.addPath(tilePath)
    ctx.clip()
    let bg = CGGradient(colorsSpace: cs,
                        colors: [c(0.20, 0.22, 0.25), c(0.094, 0.105, 0.122)] as CFArray,
                        locations: [0, 1])!
    ctx.drawLinearGradient(bg, start: CGPoint(x: rect.midX, y: rect.minY),
                           end: CGPoint(x: rect.midX, y: rect.maxY), options: [])
    ctx.restoreGState()

    // MARK: Clock geometry.
    let cx = rect.midX, cy = rect.midY
    let R = tile * 0.34

    // Subtly darker face inside the ring.
    ctx.setFillColor(c(0.06, 0.07, 0.09, 0.55))
    ctx.fillEllipse(in: CGRect(x: cx - R * 0.97, y: cy - R * 0.97, width: 2 * R * 0.97, height: 2 * R * 0.97))

    // Silver ring (full circle, metallic-ish linear gradient).
    let ring = CGMutablePath()
    ring.addEllipse(in: CGRect(x: cx - R, y: cy - R, width: 2 * R, height: 2 * R))
    strokeGradient(ring, lineWidth: max(1, tile * 0.030),
                   colors: [c(0.94, 0.96, 0.98), c(0.72, 0.76, 0.80), c(0.49, 0.53, 0.58)],
                   start: CGPoint(x: cx - R, y: cy - R), end: CGPoint(x: cx + R, y: cy + R))

    // Blue progress arc from 12 o'clock clockwise to ~4:30.
    let arc = CGMutablePath()
    let startDeg: CGFloat = 1, endDeg: CGFloat = 135, steps = 64
    for i in 0...steps {
        let d = startDeg + (endDeg - startDeg) * CGFloat(i) / CGFloat(steps)
        let p = pt(cx, cy, R, d)
        if i == 0 { arc.move(to: p) } else { arc.addLine(to: p) }
    }
    strokeGradient(arc, lineWidth: max(1, tile * 0.034),
                   colors: [c(0.45, 0.79, 1.0), c(0.04, 0.52, 1.0)],
                   start: pt(cx, cy, R, 0), end: pt(cx, cy, R, endDeg))

    // Tick marks.
    ctx.setStrokeColor(c(0.80, 0.83, 0.86, 0.95))
    ctx.setLineWidth(max(1, tile * 0.012))
    ctx.setLineCap(.round)
    for i in 0..<12 {
        let d = CGFloat(i) * 30
        ctx.move(to: pt(cx, cy, R * 0.68, d))
        ctx.addLine(to: pt(cx, cy, R * 0.80, d))
    }
    ctx.strokePath()

    // Hands (classic 10:10 pose) + hub.
    func hand(deg: CGFloat, len: CGFloat, width: CGFloat) {
        ctx.setStrokeColor(c(0.97, 0.98, 0.99))
        ctx.setLineWidth(width)
        ctx.setLineCap(.round)
        ctx.move(to: CGPoint(x: cx, y: cy))
        ctx.addLine(to: pt(cx, cy, len, deg))
        ctx.strokePath()
    }
    hand(deg: 300, len: R * 0.46, width: max(1.5, tile * 0.030)) // hour ~10
    hand(deg: 62,  len: R * 0.66, width: max(1.2, tile * 0.024)) // minute ~2
    let hub = tile * 0.022
    ctx.setFillColor(c(1, 1, 1))
    ctx.fillEllipse(in: CGRect(x: cx - hub, y: cy - hub, width: 2 * hub, height: 2 * hub))

    // Accent blue dot, lower-right.
    let dot = tile * 0.038
    let dp = CGPoint(x: cx + tile * 0.27, y: cy + tile * 0.27)
    ctx.setFillColor(c(0.04, 0.52, 1.0))
    ctx.fillEllipse(in: CGRect(x: dp.x - dot, y: dp.y - dot, width: 2 * dot, height: 2 * dot))

    guard let cg = ctx.makeImage() else { fatalError("image") }
    let rep = NSBitmapImageRep(cgImage: cg)
    rep.size = NSSize(width: pixel, height: pixel)
    guard let data = rep.representation(using: .png, properties: [:]) else { fatalError("png") }
    return data
}

// (filename, pixel size)
let files: [(String, Int)] = [
    ("AppIcon-16.png", 16),
    ("AppIcon-16@2x.png", 32),
    ("AppIcon-32.png", 32),
    ("AppIcon-32@2x.png", 64),
    ("AppIcon-128.png", 128),
    ("AppIcon-128@2x.png", 256),
    ("AppIcon-256.png", 256),
    ("AppIcon-256@2x.png", 512),
    ("AppIcon-512.png", 512),
    ("AppIcon-512@2x.png", 1024),
]

for (name, px) in files {
    let data = drawIcon(pixel: px)
    let url = URL(fileURLWithPath: outDir).appendingPathComponent(name)
    try! data.write(to: url)
    print("wrote \(name) (\(px)px, \(data.count) bytes)")
}
